public interface Strategy {
   public void doOperation(String Name);
}