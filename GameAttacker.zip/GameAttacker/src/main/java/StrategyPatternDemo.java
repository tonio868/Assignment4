

    public class StrategyPatternDemo {
   public static void main(String[] args) {
       
      Context context = new Context(new Spear());		
       String Name= "Alex";
      context.executeStrategy(Name);

      context = new Context(new Sword());		
      context.executeStrategy(Name);

      context = new Context(new shield());		
      context.executeStrategy(Name);
   }
}

