
public class Spear implements Strategy{
   @Override
   public void doOperation(String Name) {
      System.out.println(Name+" have used the spear");
   }
}